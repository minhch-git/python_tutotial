"""
Author: Nguyen Xuan Tung
Date: 20/07/2021
Program: exercise_04_page_92.py
Problem:
    Describe the purpose of the break statement and the type of problem for which it is
    well suited.
Solution:
    Let it exit the while loop, avoid the infinite loop case.
"""