"""
Author: Nguyen Xuan Tung
Date: 20/07/2021
Program: exercise_03_page_72.py
Problem:
    Write a format operation that builds a string for the float variable amount that has
    exactly two digits of precision and a field width of zero.
Solution:

"""
amount = 14/12
print(amount)
print("%0.2f" % amount)
