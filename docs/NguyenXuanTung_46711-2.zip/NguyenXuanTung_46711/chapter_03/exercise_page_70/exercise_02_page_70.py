"""
Author: Nguyen Xuan Tung
Date: 19/07/2021
Program: exercise_02_page_70.py
Problem:
    Write a loop that prints your name 100 times. Each output should begin on a
    new line.
Solution:

"""
for count in range(100):
    print("Tonny", count)
