"""
Author: Nguyen Xuan Tung
Date: 20/07/2021
Program: exercise_06_page_85.py
Problem:
    Construct truth tables for the following Boolean expressions:
    a. not (A or B)
    b. not A and not B
Solution:
    a. False
    b. False
"""
print(not (1 == 1 or 1 > 2))
print(not 1 == 1 and not 1 > 2)

