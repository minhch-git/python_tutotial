"""
Author: Nguyen Xuan Tung
Date: 20/07/2021
Program: exercise_07_page_85.py
Problem:
    Explain the role of the trailing else part of an extended if statement.
Solution:
   In if statement, else will execute the conditions opposite to the condition of if
   statement to print the result.
"""