"""
Author: chiu cam minh
Date: 10/08/2021
Program: exersice_04_page_145.py
Problem:
    Write a loop that accumulates the sum of the numbers in a list named data.
Solution:
    
"""

list = [1,5,2,3,6,8]
sum = 0
for i in list:
    sum += i 

print(sum)
