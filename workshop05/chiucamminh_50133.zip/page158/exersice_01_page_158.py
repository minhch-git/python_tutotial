"""
Author: chiu cam minh
Date: 10/08/2021
Program: exersice_01_page_158.py
Problem:
  Give three examples of real-world objects that behave like a dictionary.

Solution:
    course = {
    "name": "javascript",
    "price": 180
  }

  car = {
    "name": "BMW",
    "color": "red",
    "price": 3000
  }

  animal = {
    "name": "fish",
    weight: 8
  }

"""
course = {
  "name": "javascript",
  "price": 180
}

car = {
  "name": "BMW",
  "color": "red",
  "price": 3000
}

animal = {
  "name": "fish",
  weight: 8
}
